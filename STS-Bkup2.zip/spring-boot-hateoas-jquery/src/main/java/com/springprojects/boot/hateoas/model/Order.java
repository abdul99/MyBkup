package com.springprojects.boot.hateoas.model;

public class Order {

	private String name;

	public Order(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
