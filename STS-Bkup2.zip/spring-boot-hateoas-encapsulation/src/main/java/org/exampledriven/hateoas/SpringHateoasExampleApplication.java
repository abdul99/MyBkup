package org.exampledriven.hateoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHateoasExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringHateoasExampleApplication.class, args);
    }
}
