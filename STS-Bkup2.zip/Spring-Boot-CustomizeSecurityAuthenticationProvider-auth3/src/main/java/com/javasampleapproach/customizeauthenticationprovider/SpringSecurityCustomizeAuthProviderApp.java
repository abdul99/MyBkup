package com.javasampleapproach.customizeauthenticationprovider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityCustomizeAuthProviderApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityCustomizeAuthProviderApp.class, args);
	}
}
