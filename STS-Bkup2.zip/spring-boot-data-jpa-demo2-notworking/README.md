﻿JTechLog Spring Data
====================

Ez a program a JTechLog (<http://jtechlog.blogspot.com>) blog "Spring Data" cikkéhez készült példaprogram. 
Prezentálja a Spring Data JPA használatát. Csak JPA perzisztens réteg és teszt esetek. 
Maven-nel build-elhető, és a letöltést követően a 
'mvn package' paranccsal buildelhető (a teszt esetek is lefutnak). 

Felhasznált technológiák: lásd `pom.xml`

viczian.istvan a gmail-en