# How-To Authenticate & Authorise with MongoDB & Spring  
## Spring Security & Spring Boot & Jongo & MongoDB 

The project follows [a post on ingini.org](http://ingini.org/2015/03/26/authentication-authorization-schema-design-with-mongodb/)
