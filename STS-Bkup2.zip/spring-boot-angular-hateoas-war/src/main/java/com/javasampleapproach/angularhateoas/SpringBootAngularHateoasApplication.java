package com.javasampleapproach.angularhateoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAngularHateoasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAngularHateoasApplication.class, args);
	}
}
