# recognitions-boot
Bristech 2016 - Example colleague recognitions Spring Boot project using MongoDB.

Have a look at the slides included from the workshop given at Bristech 2016:
https://github.com/bjedrzejewski/recognitions-boot/raw/master/SpringBristech2016.pptx

This project is also featured in the 'Spring Boot and MongoDB - a Perfect Match' blog post:
http://blog.scottlogic.com/2016/11/22/spring-boot-and-mongodb.html
