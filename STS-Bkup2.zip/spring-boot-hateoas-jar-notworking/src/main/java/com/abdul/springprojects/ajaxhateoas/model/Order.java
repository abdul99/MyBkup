package com.abdul.springprojects.ajaxhateoas.model;

public class Order {

	private String name;

	public Order(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
