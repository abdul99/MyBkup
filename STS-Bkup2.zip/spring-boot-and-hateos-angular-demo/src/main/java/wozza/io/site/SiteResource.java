package wozza.io.site;

import org.springframework.hateoas.ResourceSupport;

public class SiteResource extends ResourceSupport {

}
